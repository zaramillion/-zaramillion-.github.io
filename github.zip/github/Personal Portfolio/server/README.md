# Portfolio Contact Form Backend

This is a simple Node.js/Express server that handles the contact form submissions from your portfolio website.

## Setup Instructions

### Prerequisites
- Node.js (v14 or higher)
- npm (v6 or higher)

### Installation

1. Navigate to the server directory:
   ```
   cd "Personal Portfolio/server"
   ```

2. Install dependencies:
   ```
   npm install
   ```

3. Configure environment variables:
   - Rename `.env.example` to `.env` (or create a new `.env` file)
   - Update the following variables in the `.env` file:
     - `EMAIL_SERVICE`: Your email service (e.g., gmail, outlook)
     - `EMAIL_USER`: Your email address
     - `EMAIL_PASS`: Your email password or app password
     - `RECIPIENT_EMAIL`: Email address where you want to receive contact form submissions
     - `ALLOWED_ORIGIN`: URL of your portfolio website (for CORS)

   Note: If you're using Gmail, you'll need to create an "App Password" in your Google Account settings.

### Running the Server

Development mode (with auto-restart on file changes):
```
npm run dev
```

Production mode:
```
npm start
```

The server will run on port 3000 by default. You can change this by setting the `PORT` environment variable.

## API Endpoints

### POST /api/contact
Handles contact form submissions.

Request body:
```json
{
  "name": "Visitor Name",
  "email": "visitor@example.com",
  "message": "Hello, I'd like to connect!"
}
```

Response (success):
```json
{
  "success": true,
  "message": "Your message has been sent successfully!"
}
```

### GET /api/health
Health check endpoint to verify the server is running.

Response:
```json
{
  "status": "Server is running"
}
```

## Security Considerations

- The server uses CORS to restrict which domains can make requests to the API
- Input validation is performed on all form fields
- Error handling prevents sensitive information from being exposed

## Troubleshooting

If you encounter issues with sending emails:
1. Check your email service provider's security settings
2. Verify your credentials in the `.env` file
3. For Gmail, ensure you're using an App Password if 2FA is enabled
